#include "optimizationFunction.h"

OptimizationFunction::OptimizationFunction() {

}

OptimizationFunction::~OptimizationFunction() {

}