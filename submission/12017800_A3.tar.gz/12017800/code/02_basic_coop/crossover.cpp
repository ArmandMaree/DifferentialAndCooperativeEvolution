#include "crossover.h"

Crossover::Crossover() {

}

Crossover::~Crossover() {

}