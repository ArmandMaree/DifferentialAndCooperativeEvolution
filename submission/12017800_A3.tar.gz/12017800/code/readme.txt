To run any of the implementations use the following command in each sub folder:

make args="# true" all

Replace # with the number of dimensions, eg:
make args="50 true" all
make args="1000 true" all